HeroQuest character sheet blanks.

The .sxw files are for OpenOffice.org v1.1 (Not 1.0.x)
The .doc files are for Word 2000 (or later?)

L* => letter size paper
A4* => A4 paper size.